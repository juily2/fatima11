import * as THREE from "three";
import "./style.css";

/*
  VOXEL WORLD
  A self-contained browser voxel sandbox.
  No models/textures are required: terrain, trees, clouds, sun, water,
  character and blocks are generated procedurally.
*/

const $ = (s) => document.querySelector(s);
const app = $("#app");

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: "high-performance"
});
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.65));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
app.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x74a9d8);
scene.fog = new THREE.Fog(0x74a9d8, 48, 145);

const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, .05, 220);
camera.position.set(8, 8, 10);

const clock = new THREE.Clock();
const raycaster = new THREE.Raycaster();
const center = new THREE.Vector2(0, 0);

const WORLD = 48;
const WATER_LEVEL = 7;
const MAX_BUILD_HEIGHT = 32;
const blocks = new Map();
const meshes = new Map();
const materials = {};
let selected = 0;
let firstPerson = false;
let yaw = Math.PI;
let pitch = .12;
let dayTime = .28;
let velocityY = 0;
let grounded = false;
let breaking = false;
let placing = false;
let targetBlock = null;

const TYPES = [
  {name:"grass", color:0x72b957},
  {name:"dirt", color:0x89603e},
  {name:"stone", color:0x7d8584},
  {name:"wood", color:0x8e623d},
  {name:"leaves", color:0x4e9557},
  {name:"sand", color:0xd4c184},
  {name:"glass", color:0xa6d6dd, transparent:true},
  {name:"brick", color:0x9c5146}
];

for (const t of TYPES) {
  materials[t.name] = new THREE.MeshStandardMaterial({
    color:t.color,
    roughness:t.name === "glass" ? .2 : .88,
    metalness:0,
    transparent:!!t.transparent,
    opacity:t.transparent ? .45 : 1
  });
}

const ambient = new THREE.HemisphereLight(0xdaf3ff, 0x526a55, 1.8);
scene.add(ambient);

const sun = new THREE.DirectionalLight(0xfff0c4, 3.2);
sun.castShadow = true;
sun.shadow.mapSize.set(1536,1536);
sun.shadow.camera.left = -60;
sun.shadow.camera.right = 60;
sun.shadow.camera.top = 60;
sun.shadow.camera.bottom = -60;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 170;
scene.add(sun);

const world = new THREE.Group();
scene.add(world);

function key(x,y,z){return `${x}|${y}|${z}`}
function heightAt(x,z){
  const a = Math.sin(x*.115)*2.1 + Math.cos(z*.13)*1.8;
  const b = Math.sin((x+z)*.055)*3.4;
  const c = Math.cos(x*.31+z*.17)*.65;
  return Math.max(3, Math.floor(9+a+b+c));
}
function inWorld(x,z){return x >= -WORLD && x <= WORLD && z >= -WORLD && z <= WORLD}

function setBlock(x,y,z,type, rebuild=true){
  if(!inWorld(x,z) || y<0 || y>MAX_BUILD_HEIGHT) return;
  const k=key(x,y,z);
  if(type==null) blocks.delete(k); else blocks.set(k,type);
  if(rebuild) rebuildChunkAround(x,z);
}
function getBlock(x,y,z){return blocks.get(key(x,y,z))}

function generateTerrain(){
  blocks.clear();
  for(let x=-WORLD;x<=WORLD;x++){
    for(let z=-WORLD;z<=WORLD;z++){
      const h=heightAt(x,z);
      for(let y=0;y<=h;y++){
        let type = y===h ? "grass" : y>h-4 ? "dirt" : "stone";
        if(h<=WATER_LEVEL+1 && y===h) type="sand";
        blocks.set(key(x,y,z),type);
      }
      // Occasional underground stone variation.
      if((x*17+z*31)%29===0 && h>8) blocks.set(key(x,h-1,z),"stone");
    }
  }

  // River-like water strip.
  for(let x=-WORLD;x<=WORLD;x++){
    const riverZ=Math.round(Math.sin(x*.13)*8);
    for(let dz=-2;dz<=2;dz++){
      const z=riverZ+dz;
      const h=heightAt(x,z);
      if(h<=WATER_LEVEL+1){
        for(let y=h+1;y<=WATER_LEVEL;y++) blocks.set(key(x,y,z),"water");
      }
    }
  }

  // Trees.
  for(let x=-WORLD+3;x<WORLD-2;x+=3){
    for(let z=-WORLD+3;z<WORLD-2;z+=3){
      const h=heightAt(x,z);
      const chance=Math.sin(x*12.7+z*7.3)*.5+.5;
      if(chance>.78 && h>WATER_LEVEL+2 && Math.abs(x)<44 && Math.abs(z)<44){
        addTree(x,h+1,z);
      }
    }
  }

  // A small starter cabin area.
  buildCabin(-10, heightAt(-10, -5)+1, -5);
}

function addTree(x,y,z){
  for(let i=0;i<4;i++) blocks.set(key(x,y+i,z),"wood");
  for(let dx=-2;dx<=2;dx++) for(let dz=-2;dz<=2;dz++) for(let dy=2;dy<=4;dy++){
    const d=Math.abs(dx)+Math.abs(dz)+(dy===4?1:0);
    if(d<=4 && !getBlock(x+dx,y+dy,z+dz)) blocks.set(key(x+dx,y+dy,z+dz),"leaves");
  }
  blocks.set(key(x,y+5,z),"leaves");
}

function buildCabin(x,y,z){
  for(let dx=0;dx<7;dx++) for(let dz=0;dz<6;dz++){
    for(let dy=0;dy<4;dy++){
      const edge=dx===0||dx===6||dz===0||dz===5;
      if(edge && !(dy===1 && dz===5 && dx>=2 && dx<=4)) blocks.set(key(x+dx,y+dy,z+dz),"wood");
    }
    blocks.set(key(x+dx,y+4,z+dz),"brick");
  }
  // doorway
  for(let dy=0;dy<2;dy++) for(let dx=2;dx<=4;dx++) blocks.delete(key(x+dx,y+dy,z+5));
  // windows
  blocks.set(key(x+1,y+2,z),"glass");
  blocks.set(key(x+5,y+2,z),"glass");
}

function rebuildAll(){
  for(const m of meshes.values()) world.remove(m);
  meshes.clear();

  // Instanced geometry by block type. One mesh per type is much faster than one Mesh per cube.
  const byType={};
  for(const [k,t] of blocks){
    if(t==="water") continue;
    (byType[t] ||= []).push(k);
  }

  const cubeGeo=new THREE.BoxGeometry(1,1,1);
  for(const [type,keys] of Object.entries(byType)){
    const mesh=new THREE.InstancedMesh(cubeGeo,materials[type],keys.length);
    mesh.castShadow=type!=="glass";
    mesh.receiveShadow=true;
    const dummy=new THREE.Object3D();
    keys.forEach((k,i)=>{
      const [x,y,z]=k.split("|").map(Number);
      dummy.position.set(x+.5,y+.5,z+.5);
      dummy.updateMatrix();
      mesh.setMatrixAt(i,dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate=true;
    mesh.userData.keys=keys;
    mesh.userData.type=type;
    world.add(mesh);
    meshes.set(type,mesh);
  }

  // Water surface.
  const waterGeo=new THREE.PlaneGeometry(1,1);
  const waterMat=new THREE.MeshStandardMaterial({
    color:0x4a9fb3,transparent:true,opacity:.58,roughness:.12,metalness:.05
  });
  const waterKeys=[...blocks.entries()].filter(([k,t])=>t==="water").map(([k])=>k);
  if(waterKeys.length){
    const water=new THREE.InstancedMesh(waterGeo,waterMat,waterKeys.length);
    water.rotation.x=-Math.PI/2;
    const dummy=new THREE.Object3D();
    waterKeys.forEach((k,i)=>{
      const [x,y,z]=k.split("|").map(Number);
      dummy.position.set(x+.5,y+.03,z+.5);
      dummy.rotation.x=-Math.PI/2;
      dummy.updateMatrix();
      water.setMatrixAt(i,dummy.matrix);
    });
    water.instanceMatrix.needsUpdate=true;
    world.add(water);
    meshes.set("water",water);
  }
}

generateTerrain();
rebuildAll();

// Decorative clouds.
const clouds=new THREE.Group();
scene.add(clouds);
function cloud(x,y,z,s=1){
  const g=new THREE.Group();g.position.set(x,y,z);g.scale.setScalar(s);
  for(let i=0;i<5;i++){
    const p=new THREE.Mesh(new THREE.SphereGeometry(2.2+(i%2)*.7,12,8),new THREE.MeshStandardMaterial({color:0xf2f5ef,roughness:1}));
    p.position.set((i-2)*2.1,(i%2)*.45,Math.sin(i)*.7);
    g.add(p);
  }
  clouds.add(g);
}
cloud(-32,30,-28,1.2);cloud(18,34,-10,.9);cloud(-2,31,27,1.3);cloud(36,29,18,.8);

// Player.
const player=new THREE.Group();
player.position.set(0,heightAt(0,8)+1.02,8);
scene.add(player);

const bodyMat=materials.playerBody=new THREE.MeshStandardMaterial({color:0x5e8fbd,roughness:.8});
const skinMat=materials.skin=new THREE.MeshStandardMaterial({color:0xd4a27e,roughness:.9});
const darkMat=new THREE.MeshStandardMaterial({color:0x2d3032,roughness:.9});
const body=new THREE.Mesh(new THREE.BoxGeometry(.72,1.05,.45),bodyMat);
body.position.y=.95;body.castShadow=true;player.add(body);
const head=new THREE.Mesh(new THREE.BoxGeometry(.68,.68,.68),skinMat);
head.position.y=1.8;head.castShadow=true;player.add(head);
const hair=new THREE.Mesh(new THREE.BoxGeometry(.72,.22,.72),darkMat);
hair.position.y=2.14;hair.castShadow=true;player.add(hair);
const armL=new THREE.Mesh(new THREE.BoxGeometry(.23,.85,.25),bodyMat),armR=armL.clone();
armL.position.set(-.52,1,0);armR.position.set(.52,1,0);armL.castShadow=armR.castShadow=true;player.add(armL,armR);
const legL=new THREE.Mesh(new THREE.BoxGeometry(.25,.8,.28),darkMat),legR=legL.clone();
legL.position.set(-.2,.25,0);legR.position.set(.2,.25,0);legL.castShadow=legR.castShadow=true;player.add(legL,legR);

// Third-person camera follows a separate pivot.
const cameraTarget=new THREE.Vector3();
let cameraDistance=6.5;

function solidAt(x,y,z){
  const bx=Math.floor(x),by=Math.floor(y),bz=Math.floor(z);
  const t=getBlock(bx,by,bz);
  return t && t!=="water";
}
function collides(px,py,pz){
  const r=.32,h=1.95;
  for(let x=Math.floor(px-r);x<=Math.floor(px+r);x++)
    for(let y=Math.floor(py);y<=Math.floor(py+h);y++)
      for(let z=Math.floor(pz-r);z<=Math.floor(pz+r);z++)
        if(solidAt(x+.5,y+.01,z+.5)) return true;
  return false;
}

const keys={};
addEventListener("keydown",e=>{
  keys[e.code]=true;
  if(/^Digit[1-8]$/.test(e.code)){selected=Number(e.code.slice(-1))-1;updateSlots()}
  if(e.code==="KeyV")toggleView();
  if(e.code==="Space" && grounded) {velocityY=8.5;grounded=false}
  if(e.code==="KeyH")$("#helpPanel").classList.toggle("hidden");
  if(e.code==="KeyQ") breakTarget();
  if(e.code==="KeyE") placeTarget();
  if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code))e.preventDefault();
});
addEventListener("keyup",e=>keys[e.code]=false);

let mouseLook=false;
renderer.domElement.addEventListener("pointerdown",e=>{
  if(e.pointerType==="mouse"){
    if(e.button===0){breakTarget()}
    if(e.button===2){placeTarget();e.preventDefault()}
    mouseLook=true;
  }
});
addEventListener("pointerup",()=>mouseLook=false);
addEventListener("pointermove",e=>{
  if(mouseLook && e.pointerType==="mouse"){
    yaw-=e.movementX*.0035;
    pitch=THREE.MathUtils.clamp(pitch-e.movementY*.0025,-.9,1.1);
  }
});
renderer.domElement.addEventListener("contextmenu",e=>e.preventDefault());

// Mobile joystick.
const moveInput={x:0,z:0};
let joyId=null,cx=0,cy=0;
$("#movePad").addEventListener("pointerdown",e=>{
  joyId=e.pointerId;
  const r=$("#movePad").getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;
  $("#movePad").setPointerCapture(joyId);updateJoy(e);
});
$("#movePad").addEventListener("pointermove",e=>{if(e.pointerId===joyId)updateJoy(e)});
$("#movePad").addEventListener("pointerup",()=>{
  joyId=null;moveInput.x=moveInput.z=0;$("#moveStick").style.transform="translate(0,0)"
});
function updateJoy(e){
  let dx=e.clientX-cx,dy=e.clientY-cy,len=Math.hypot(dx,dy),max=50;
  if(len>max){dx=dx/len*max;dy=dy/len*max}
  moveInput.x=dx/max;moveInput.z=dy/max;
  $("#moveStick").style.transform=`translate(${dx}px,${dy}px)`;
}

// Touch look area: the whole right-middle canvas is available.
let touchLook=null;
renderer.domElement.addEventListener("pointerdown",e=>{
  if(e.pointerType==="touch" && e.clientX>innerWidth*.38){
    touchLook={id:e.pointerId,x:e.clientX,y:e.clientY};
  }
});
renderer.domElement.addEventListener("pointermove",e=>{
  if(touchLook?.id===e.pointerId){
    yaw-=(e.clientX-touchLook.x)*.006;
    pitch=THREE.MathUtils.clamp(pitch-(e.clientY-touchLook.y)*.004,-.8,1);
    touchLook.x=e.clientX;touchLook.y=e.clientY;
  }
});
addEventListener("pointerup",e=>{if(touchLook?.id===e.pointerId)touchLook=null});

$("#jumpBtn").addEventListener("pointerdown",()=>{if(grounded){velocityY=8.5;grounded=false}});
$("#viewBtn").addEventListener("pointerdown",toggleView);
$("#breakBtn").addEventListener("pointerdown",breakTarget);
$("#placeBtn").addEventListener("pointerdown",placeTarget);

function toggleView(){
  firstPerson=!firstPerson;
  $("#modeBadge").textContent=firstPerson?"FIRST PERSON":"THIRD PERSON";
  body.visible=!firstPerson;
}
function updateSlots(){
  document.querySelectorAll(".slot").forEach((s,i)=>s.classList.toggle("selected",i===selected));
}
document.querySelectorAll(".slot").forEach((s,i)=>s.addEventListener("pointerdown",()=>{selected=i;updateSlots()}));
$("#helpBtn").addEventListener("pointerdown",()=>$("#helpPanel").classList.remove("hidden"));
$("#closeHelp").addEventListener("pointerdown",()=>$("#helpPanel").classList.add("hidden"));

// Voxel edit: raycast visible cube and alter one block at a time.
// Rebuilds the small world mesh, which is appropriate for this compact sandbox.
function pickBlock(){
  raycaster.setFromCamera(center,camera);
  const hits=[];
  for(const [type,m] of meshes){
    if(type!=="water") hits.push(...raycaster.intersectObject(m,false));
  }
  if(!hits.length)return null;
  const hit=hits.sort((a,b)=>a.distance-b.distance)[0];
  const type=hit.object.userData.type;
  const k=hit.object.userData.keys[hit.instanceId];
  if(!k)return null;
  const [x,y,z]=k.split("|").map(Number);
  return {x,y,z,type,normal:hit.face.normal.clone(),distance:hit.distance};
}
function breakTarget(){
  const hit=pickBlock();
  if(!hit || hit.distance>8 || hit.y<=0)return;
  setBlock(hit.x,hit.y,hit.z,null);
}
function placeTarget(){
  const hit=pickBlock();
  if(!hit || hit.distance>8)return;
  const nx=hit.x+Math.round(hit.normal.x),ny=hit.y+Math.round(hit.normal.y),nz=hit.z+Math.round(hit.normal.z);
  if(ny<0||ny>MAX_BUILD_HEIGHT)return;
  if(getBlock(nx,ny,nz))return;
  // Avoid placing a block inside the player.
  const px=player.position.x,pz=player.position.z,py=player.position.y;
  if(Math.abs(px-(nx+.5))<.8 && Math.abs(pz-(nz+.5))<.8 && Math.abs(py-(ny+.5))<1.8)return;
  setBlock(nx,ny,nz,TYPES[selected].name);
}

// Movement.
function input(){
  let x=0,z=0;
  if(keys.KeyA||keys.ArrowLeft)x--;
  if(keys.KeyD||keys.ArrowRight)x++;
  if(keys.KeyW||keys.ArrowUp)z--;
  if(keys.KeyS||keys.ArrowDown)z++;
  if(!x&&!z){x=moveInput.x;z=moveInput.z}
  const len=Math.hypot(x,z);
  if(len>1){x/=len;z/=len}
  return {x,z};
}

function move(dt,time){
  const i=input();
  const moving=Math.hypot(i.x,i.z)>.08;
  const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
  const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
  const dir=forward.multiplyScalar(-i.z).add(right.multiplyScalar(i.x));
  if(dir.lengthSq()>0)dir.normalize();

  const speed=keys.ShiftLeft||keys.ShiftRight?8.5:5.8;
  const dx=dir.x*speed*dt,dz=dir.z*speed*dt;

  if(!collides(player.position.x+dx,player.position.y,player.position.z))player.position.x+=dx;
  if(!collides(player.position.x,player.position.y,player.position.z+dz))player.position.z+=dz;

  velocityY-=22*dt;
  let ny=player.position.y+velocityY*dt;
  if(collides(player.position.x,ny,player.position.z) && velocityY<0){
    ny=Math.ceil(ny);
    velocityY=0;grounded=true;
  }else grounded=false;
  if(ny<0){ny=1;velocityY=0;grounded=true}
  player.position.y=ny;

  if(moving){
    player.rotation.y=THREE.MathUtils.lerp(player.rotation.y,Math.atan2(dir.x,dir.z),.18);
    const walk=Math.sin(time*10)*.65;
    legL.rotation.x=walk;legR.rotation.x=-walk;armL.rotation.x=-walk*.7;armR.rotation.x=walk*.7;
  }else{
    legL.rotation.x*=.8;legR.rotation.x*=.8;armL.rotation.x*=.8;armR.rotation.x*=.8;
  }
}

function updateCamera(dt){
  const targetY=player.position.y+(firstPerson?1.65:1.15);
  cameraTarget.set(player.position.x,targetY,player.position.z);

  if(firstPerson){
    camera.position.lerp(cameraTarget,1-Math.pow(.001,dt));
    camera.rotation.order="YXZ";
    camera.rotation.y=yaw;
    camera.rotation.x=pitch;
  }else{
    const horizontal=Math.cos(pitch)*cameraDistance;
    const desired=new THREE.Vector3(
      player.position.x+Math.sin(yaw)*horizontal,
      targetY+Math.sin(pitch)*cameraDistance+1.4,
      player.position.z+Math.cos(yaw)*horizontal
    );
    camera.position.lerp(desired,1-Math.pow(.0008,dt));
    camera.lookAt(cameraTarget);
  }
}

function updateLighting(dt,time){
  dayTime=(dayTime+dt*.006)%1;
  const angle=dayTime*Math.PI*2;
  sun.position.set(Math.cos(angle)*55,Math.sin(angle)*70,Math.sin(angle)*45);
  const daylight=THREE.MathUtils.clamp((sun.position.y+10)/75,.08,1);
  sun.intensity=.5+daylight*3.0;
  ambient.intensity=.65+daylight*1.6;
  const sky=new THREE.Color().setHSL(.57,.48,.45+daylight*.18);
  scene.background.lerp(sky,.02);
  scene.fog.color.lerp(sky,.02);
  $("#day").textContent=String(Math.floor(dayTime*24)).padStart(2,"0");
}

let fpsFrames=0,fpsTime=0;
function updateHud(dt){
  fpsFrames++;fpsTime+=dt;
  if(fpsTime>.5){
    $("#fps").textContent=Math.round(fpsFrames/fpsTime);
    fpsFrames=0;fpsTime=0;
  }
  $("#pos").textContent=`${Math.floor(player.position.x)}, ${Math.floor(player.position.y)}, ${Math.floor(player.position.z)}`;
}

function animate(){
  const dt=Math.min(clock.getDelta(),.035);
  const time=clock.elapsedTime;
  move(dt,time);
  updateCamera(dt);
  updateLighting(dt,time);
  updateHud(dt);
  clouds.children.forEach((c,i)=>c.position.x+=dt*(.12+i*.02));

  targetBlock=pickBlock();
  renderer.render(scene,camera);
}
renderer.setAnimationLoop(animate);

addEventListener("resize",()=>{
  camera.aspect=innerWidth/innerHeight;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.65));
  renderer.setSize(innerWidth,innerHeight);
});

// Start screen.
setTimeout(()=>$("#boot").classList.add("done"),1600);
