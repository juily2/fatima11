# Voxel World

一个独立的、横屏优先的浏览器体素沙盒游戏。

它不是把 Minecraft 网页 UI 搬过来，而是从零用 Three.js 做了一个可探索、可建造的 voxel world。

## 已实现

- 第一人称 / 第三人称切换
- 横屏移动端 UI
- 竖屏自动提示旋转手机
- 手机虚拟摇杆
- 手机触摸拖动视角
- 手机 BREAK / PLACE / JUMP / VIEW
- PC WASD / 方向键
- Shift 冲刺
- 鼠标视角
- 空格跳跃
- 重力
- 方块碰撞
- 方块破坏与放置
- 8 种方块
- 程序化山地
- 河流和水面
- 树木
- 小木屋
- 云
- 太阳光
- 动态昼夜
- 雾
- 阴影
- 热栏
- 坐标 / FPS / 时间 HUD
- 无外部模型依赖
- Vite 构建
- GitHub Pages 工作流

## 本地 / Codespaces

```bash
npm install
npm run dev
```

然后打开 Vite 的 5173 端口。

## GitHub Pages

这个项目已经包含 `.github/workflows/pages.yml`。

把整个项目推送到 GitHub 后：

1. GitHub 仓库进入 Settings
2. Pages
3. Source 选择 GitHub Actions
4. 推送到 main
5. Actions 自动构建和部署

## 重要

这是一个浏览器体素沙盒原型。世界使用程序生成的方块，没有复制 Minecraft 的专有模型、纹理或代码。

如果继续开发，可以加入：
- 区块 Chunk streaming
- 保存 / 读取世界
- 生物 AI
- 背包系统
- 真实物理
- 更多方块
- 山洞 / 矿物
- 天气
- 粒子
- 声音
- 多人联机
